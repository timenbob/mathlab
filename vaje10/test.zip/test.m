T1 = [1; 5];
T2 = [7; 3];

cas = brahistohrona(T1,T2)
%[theta,k] = poisciOpt_theta_k(T2(1)-1,T2(2)-5);
%theta
%k