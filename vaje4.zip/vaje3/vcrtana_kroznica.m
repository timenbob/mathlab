function [S,r]=vcrtana_kroznica(T)
% vcrtana_kroznica vrne sredisce in radij vcrtane kroznice
% [S,r]=vcrtana_kroznica(T) vrne sredisce in radij trikotniku T vcrtanega kroga
% T je podan kot 3x2 matrika tock: [x1 y1; x2 y2; x3 y3].

%simetrale kotov presečišče da sredino