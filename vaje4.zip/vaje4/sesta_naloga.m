%pomembno tudi na kvizih
format long
fun2=@(t) fun1(t)+300;
fzero(fun2,5)
