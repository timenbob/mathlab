%4
%višina po 300 sekundah
%y(end)